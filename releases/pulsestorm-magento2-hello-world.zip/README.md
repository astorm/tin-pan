# magento2-hello-world
A simple Hello World model for Magento 2 MVVM (or MVVM like) system.

http://alanstorm.com/magento_2_mvvm_mvc
